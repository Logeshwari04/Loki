package com.intern.Logu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoguApplicationTests {

	@Test
	void contextLoads() {
	}

}
